# N1-PDM
## PEDRO DELLA ROSA ANTÔNIO  
### RA: 24026018

#### Descrição do Projeto:

- Android Studio
- Java

Aplicativo Android em Java que calcula o IMC (Indíce de Massa Corporal), exibindo após o calculo um FeedBack para cada categoria de IMC, sendo elas: Abaixo do Peso, Peso Normal, Sobrepeso e Obesidade (Grau 1, 2 e 3).
